<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <div>
     getTest1 - - -  {{ getTestMsg1 }}
    </div>
    <div>
     getTest2 - - -  {{ getTestMsg2 }}
    </div>
    <button @click="getTestMsgFun1({'name':'Charid1'})">发送Get1请求</button>
    <button @click="getTestMsgFun2('charid2')">发送Get2请求</button>
    <hr>
    <div>
      postTestMsg1 - - -  {{ postTestMsg1 }}
    </div>
    <div>
      postTestMsg2 - - -  {{ postTestMsg2 }}
    </div>
    <button @click="postTestMsgFun1">发送post1请求</button>
    <button @click="postTestMsgFun2">发送post2请求</button>
    <hr>
    <ImageUpload />
    <hr>
    <div>
     <button @click="downloadFile('testImg.png')">testImg.png</button>
     <button @click="downloadFile('testa.pdf')">testa.pdf</button>
     <button @click="downloadFile('testc.zip')">testc.zip</button>
     <div v-if="showProgress">
      <p>Download Progress: {{ downloadProgress }}%</p>
      <progress :value="downloadProgress" max="100">{{ downloadProgress }}%</progress>
     </div>
    </div>

  </div>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'
import { getTest,getTest1 } from './api/getTest'
import { postTest1,postTest2 } from './api/postTest'
import ImageUpload from './components/ImageUpload'
import {downloadTest} from './api/download'

export default {
  name: 'App',
  data () {
    return {
      getTestMsg1: "",
      getTestMsg2: "",
      postTestMsg1: "",
      postTestMsg2:"",
      showProgress: false,
      downloadProgress: 0,
    }
  },
  components:{
    ImageUpload
  },
  methods:{
     getTestMsgFun1(nameObj){
       getTest(nameObj).then(res => {
         console.log("111111111111111111111111111111111",res)
         this.getTestMsg1 = res
       }).catch(()=>{})
     },
     async getTestMsgFun2(name){
       try {
         const res = await getTest1(name)
         console.log("222222222222222222222222222222222",res)
         this.getTestMsg2 = res
       } catch (error) {
        // 这里做报错的提示
        //  console.log(error)
       }
     },
     postTestMsgFun1(){
      const data = {
        name: 'postTest1',
        age: 18
      }
      postTest1(data).then((res)=>{
        console.log("111111111111111111111111111111111",res)
        this.postTestMsg1 = res
      }).catch(()=>{})
     },
     async postTestMsgFun2(){
      const data = {
        name: 'postTest2',
        age: 20
      }
      await postTest2(data).then((res)=>{
        console.log("22222222222222222222222",res)
      }).catch(()=>{})
     },
     async downloadFile(filename) {
      const setdownloadProgress = (rate) =>{
        this.downloadProgress = rate
      }
      try {
        this.showProgress = true;

        const response = await downloadTest({"filename":filename},setdownloadProgress)
        console.log("aaaaaaaaaaaaaaaaaaaaaaaaa",response)
         // 创建 Blob 对象和下载链接
         const blob = new Blob([response.data]);
        const url = window.URL.createObjectURL(blob);

        // 创建隐藏的下载链接并触发点击下载
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', filename);
        document.body.appendChild(link);
        link.click();

        // 清理对象 URL
        window.URL.revokeObjectURL(url);

        // 完成下载后重置进度条
        this.showProgress = false;
        this.downloadProgress = 0;
      } catch (error) {
        console.error('File download failed.', error);
        this.showProgress = false;
        this.downloadProgress = 0;
      }
    }
  
  },
  mounted(){
    // console.log(getTest)
  },

}
</script>

<style>

</style>
