import request from './request'

const downloadTest = (params, setdownloadProgress) => {
  return request({
    url: '/download',
    method: 'get',
    params,
    responseType: 'blob',
    onDownloadProgress: (progressEvent) => {
      console.log(progressEvent)
      setdownloadProgress(
        Math.round((progressEvent.loaded / progressEvent.total) * 100)
      )
    },
    timeout: 1000000000000,
  })
}

export { downloadTest }
