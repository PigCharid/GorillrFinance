import requset from './request'
const uploadTest = (data, setUploadProgress) => {
  return requset({
    url: '/upload',
    method: 'post',
    data,
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    onUploadProgress: function (progressEvent) {
      setUploadProgress(
        Math.round((progressEvent.loaded / progressEvent.total) * 100)
      )
    },
    timeout: 1000000,
  })
}

export { uploadTest }
