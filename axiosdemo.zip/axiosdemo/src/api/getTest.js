import requset from './request'

const getTest = (params) => {
  return requset({
    url: '/gettest',
    method: 'get',
    params,
  })
}

const getTest1 = (name) => {
  return requset({
    url: '/gettest',
    method: 'get',
    params: { name },
  })
}

export { getTest, getTest1 }
