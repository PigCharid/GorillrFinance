import axios from 'axios'

const requestInstance = axios.create({
  baseURL: 'http://localhost:3000/',
  timeout: 5000,
})
// 响应失败的情况出错会走到这里
const errorHandler = (error) => {
  let errorEntity = { code: -1, data: { error }, message: '未知错误' }
  if (error.response) {
    errorEntity.message = '网络错误'
  }
  console.log('请求错误：', errorEntity)
  return Promise.reject(errorEntity)
}

requestInstance.interceptors.request.use((config) => {
  // 在发送请求之前
  // const token = storage.get(ACCESS_TOKEN)
  const token = localStorage.getItem('token') || sessionStorage.getItem('token')
  // 如果 token 存在
  if (token) {
    // config.headers[ACCESS_TOKEN] = token
    config.headers.Authorization = `Bearer${token}`
  }
  return config
}, errorHandler)
// response interceptor
requestInstance.interceptors.response.use((response) => {
  // 一般后端把数据都返回在data字段中，所以这里直接返回data
  const res = response.data
  console.log('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')
  if (response.status !== 200) {
    // 错误情况
    return response.data || {}
  } else {
    // 这里面还可以其他的判断操作   或者文件操作？
    // 还要判断数据里面返回的状态码
    if (res.code !== 2000) {
      if (response.headers['content-type'] === 'application/octet-stream') {
        return response
      }
      console.log(res.message)
      return Promise.reject(new Error(res.message))
    } else {
      return res
    }
  }
}, errorHandler)

export default requestInstance
