import requset from './request'
const postTest1 = (data) => {
  return requset({
    url: '/posttest1',
    method: 'post',
    data,
  })
}
const postTest2 = (data) => {
  return requset({
    url: '/posttest2',
    method: 'post',
    data,
  })
}

export { postTest1, postTest2 }
