<template>
  <div>
    <input type="file" @change="onFileChange" />
    <button @click="uploadFile">Upload</button>
    <p v-if="message">{{ message }}</p>
    <div v-if="uploadProgress !== null">
      <progress :value="uploadProgress" max="100">{{ uploadProgress }}%</progress>
    </div>
  </div>
</template>
<script>
import { uploadTest } from '../api/uploadTest'
  export default {
    name: 'ImageUpload',
    data() {
      return {
        file: null,
        message: '',
        uploadProgress: null,
      }
    },
    
    methods:{
      onFileChange(event) {
      this.file = event.target.files[0];
      },
     
      async uploadFile(){
        console.log("---------------当前的文件",this.file)
        if (!this.file) {
        this.message = 'Please select a file first.';
        return;
        }
        console.log("外部的this",this)

        const setUploadProgress = (rate)=>{
            console.log("内部的this",this)
            this.uploadProgress = rate; //因为this为空  导致出错
            console.log("上传进度",rate)
        }

        const formData = new FormData();
        formData.append('image', this.file);
        try{
            const res =  await uploadTest(formData,setUploadProgress)
            console.log(res)
            this.message = res.message
        }catch(error){  
          console.log(error)
        }
      
      }
    }
  }
</script>