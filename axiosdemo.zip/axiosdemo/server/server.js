const express = require('express')
const multer = require('multer')
const path = require('path')
const fs = require('fs')
const cors = require('cors')

const app = express()
const PORT = 3000

app.use(cors())
// Middleware to parse JSON and form data
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// 中间件：设置 Content-Length 头部
app.use((req, res, next) => {
  res.on('finish', () => {
    if (
      !res.headersSent &&
      res.statusCode === 200 &&
      res.get('Content-Length') === undefined
    ) {
      const { 'Content-Length': contentLength } = res.getHeaders()
      if (typeof contentLength === 'number' && !isNaN(contentLength)) {
        res.setHeader('Content-Length', contentLength)
      }
    }
  })
  next()
})

app.use('/uploads', express.static(path.join(__dirname, 'uploads')))

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/')
  },
  filename: (req, file, cb) => {
    const originalname = Buffer.from(file.originalname, 'latin1').toString(
      'utf8'
    ) // 处理文件名中的中文字符
    // const sanitizedFilename = originalname.replace(/[^a-zA-Z0-9.\-]/g, '_')
    cb(null, originalname) // 保留源文件名
  },
})
const upload = multer({ storage })

// Ensure the uploads directory exists
if (!fs.existsSync('uploads')) {
  fs.mkdirSync('uploads')
}

// GET request handler
app.get('/gettest', (req, res) => {
  console.log(
    'getTest req ----------------------------------------------------------------',
    req.query
  )
  res.json({
    code: 2000,
    message: 'success',
    data: 'This is a GET request respons',
  })
})

// POST request handler
app.post('/posttest1', (req, res) => {
  console.log('postTest1被请求了，参数是', req.body)
  res.json({
    code: 2000,
    message: 'success',
    data: 'This is posttest1 respons',
  })
})

// POST request handler
app.post('/posttest2', (req, res) => {
  console.log('postTest2被请求了，参数是', req.body)
  res.json({
    code: 3000,
    message: 'false',
    data: 'This is posttest2 respons',
  })
})

// 图片上传接口
app.post('/upload', upload.single('image'), (req, res) => {
  console.log('upload被请求了，参数是', req.file)
  if (!req.file) {
    return res.status(400).json({
      code: 4000,
      message: '图片上传失败',
      data: '',
    })
  }
  res.status(200).json({
    code: 2000,
    message: '图片上传成功',
    data: '',
  })
})

// 文件下载接口，示例：http://localhost:3000/download?filename=test.txt
app.get('/download', (req, res) => {
  const { filename } = req.query
  console.log(filename)
  if (!filename) {
    return res.status(400).json({
      code: 4000,
      message: '文件下载失败',
      data: '',
    })
  }

  const filePath = path.join(__dirname, 'uploads', filename)
  console.log(filePath)

  // 检查文件是否存在
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ message: 'File not found' })
  }
  // 获取文件信息
  const stat = fs.statSync(filePath)
  const fileSize = stat.size
  console.log('文件的大小', fileSize)

  // 设置响应头，告诉浏览器这是一个需要下载的文件
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`)
  res.setHeader('Content-Type', 'application/octet-stream')
  res.setHeader('Content-Length', fileSize)
  // 创建可读流，读取文件内容并发送给客户端
  const fileStream = fs.createReadStream(filePath)
  fileStream.pipe(res)
})

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`)
})
